<div class="qodef-e-media">
	<?php
	firstframe_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/image', '', $params );
	?>
</div>
