<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-firstframecore-instagram-list-shortcode.php';
