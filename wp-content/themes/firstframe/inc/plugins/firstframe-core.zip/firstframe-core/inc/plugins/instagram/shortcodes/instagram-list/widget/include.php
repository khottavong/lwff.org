<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-firstframecore-instagram-list-widget.php';
