<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/checkout/helper.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/checkout/class-firstframecore-checkout-integration.php';
