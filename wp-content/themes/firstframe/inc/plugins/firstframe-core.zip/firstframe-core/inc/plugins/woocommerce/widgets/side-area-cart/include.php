<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-firstframecore-woocommerce-side-area-cart-widget.php';
