<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-firstframecore-woocommerce-dropdown-cart-widget.php';
