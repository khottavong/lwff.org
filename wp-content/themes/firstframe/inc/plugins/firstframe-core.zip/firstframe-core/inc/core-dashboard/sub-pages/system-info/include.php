<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-firstframecore-dashboard-system-info-page.php';
