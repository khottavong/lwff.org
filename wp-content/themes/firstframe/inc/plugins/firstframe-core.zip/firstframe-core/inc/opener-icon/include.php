<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/opener-icon/helper.php';
