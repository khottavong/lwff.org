<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/contact-form-7/class-firstframecore-contact-form-7.php';
