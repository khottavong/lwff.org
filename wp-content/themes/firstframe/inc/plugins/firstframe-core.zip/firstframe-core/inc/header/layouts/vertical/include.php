<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/header/layouts/vertical/helper.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/layouts/vertical/class-firstframecore-vertical-header.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/layouts/vertical/dashboard/admin/vertical-header-options.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/layouts/vertical/dashboard/meta-box/vertical-header-meta-box.php';
