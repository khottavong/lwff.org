<?php

include_once FIRSTFRAME_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/no-hover/helper.php';