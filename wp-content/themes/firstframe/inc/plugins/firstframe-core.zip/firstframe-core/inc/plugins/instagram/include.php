<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/instagram/helper.php';
