<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/icons/elegant-icons/class-firstframecore-elegant-icons-pack.php';
