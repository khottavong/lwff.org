<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/content/helper.php';
