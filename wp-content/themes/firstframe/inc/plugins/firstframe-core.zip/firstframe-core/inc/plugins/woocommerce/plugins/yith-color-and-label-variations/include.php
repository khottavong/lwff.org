<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-color-and-label-variations/dashboard/admin/woocommerce-yith-color-and-label-variations-options.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-color-and-label-variations/helper.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-color-and-label-variations/template-functions.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-color-and-label-variations/class-firstframecore-woocommerce-yith-color-and-label-variations.php';
