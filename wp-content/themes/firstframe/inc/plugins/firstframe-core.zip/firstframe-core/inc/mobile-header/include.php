<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/mobile-header/helper.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/mobile-header/class-firstframecore-mobile-header.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/mobile-header/class-firstframecore-mobile-headers.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/mobile-header/template-functions.php';
