<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-firstframecore-twitter-list-widget.php';
