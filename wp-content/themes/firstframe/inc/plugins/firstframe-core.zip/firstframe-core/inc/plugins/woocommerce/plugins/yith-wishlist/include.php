<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/dashboard/admin/woocommerce-yith-wishlist-options.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/helper.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/template-functions.php';
include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/class-firstframecore-woocommerce-yith-wishlist.php';
