<form method="post" class="qodef-checkout-buy-item" enctype="multipart/form-data">
	<?php firstframe_core_template_part( 'plugins/checkout', 'templates/content', '', $params ); ?>
</form>
