<?php

include_once FIRSTFRAME_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-firstframecore-twitter-list-shortcode.php';
