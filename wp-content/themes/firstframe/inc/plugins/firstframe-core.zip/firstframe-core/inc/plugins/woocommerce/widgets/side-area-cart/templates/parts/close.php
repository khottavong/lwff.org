<a class="qodef-m-close" href="#">
	<span class="qodef-m-close-icon"><?php echo firstframe_core_get_svg_icon( 'close' ); ?></span>
</a>
