<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/header/helper.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/class-firstframecore-header.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/class-firstframecore-headers.php';
include_once FIRSTFRAME_CORE_INC_PATH . '/header/template-functions.php';
