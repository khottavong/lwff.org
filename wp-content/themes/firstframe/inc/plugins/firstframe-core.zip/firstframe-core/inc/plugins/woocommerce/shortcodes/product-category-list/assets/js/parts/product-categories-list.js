(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.firstframe_core_product_category_list                    = {};
	qodefCore.shortcodes.firstframe_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.firstframe_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
