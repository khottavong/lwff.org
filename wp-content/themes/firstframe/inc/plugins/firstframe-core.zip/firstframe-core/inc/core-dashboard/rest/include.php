<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/core-dashboard/rest/class-firstframecore-dashboard-rest-api.php';
