(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.firstframe_core_clients_list             = {};
	qodefCore.shortcodes.firstframe_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
