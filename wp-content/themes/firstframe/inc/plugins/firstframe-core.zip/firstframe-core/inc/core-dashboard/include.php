<?php

include_once FIRSTFRAME_CORE_INC_PATH . '/core-dashboard/class-firstframecore-dashboard.php';
